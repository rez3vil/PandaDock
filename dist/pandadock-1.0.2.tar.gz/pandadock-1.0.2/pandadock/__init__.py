"""
PandaDock: A Python package for molecular docking
"""
__version__ = '1.0.1'
