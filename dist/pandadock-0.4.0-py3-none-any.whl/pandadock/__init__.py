"""
PandaDock: A Python package for molecular docking
"""
__version__ = '0.1.0'
